import React from 'react';
import './componet';

function App() {
  return (
    <div>
      
    </div>
  );
}

export default App;
