import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { Header } from './componet';
import { Main_1 } from './componet';
import { Main_2 } from './componet';
import { Main_3 } from './componet';
import { Main_4 } from './componet';
import { Main_5 } from './componet';
import { Main_6 } from './componet';
import { Main_7 } from './componet';
import { Main_8 } from './componet';
import { Main_9 } from './componet';


const root = ReactDOM.createRoot(document.getElementById('root')); // Create a root DOM node

root.render(
  <React.StrictMode>
    <App /> 
    <Header />
    <Main_1 />
    <Main_2 />
    <Main_3 />
    <Main_4 />
    <Main_5 />
    <Main_6 />
    <Main_7 />
    <Main_8 />
    <Main_9 />
  </React.StrictMode>
);
