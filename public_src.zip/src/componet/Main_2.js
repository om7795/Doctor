import React from 'react';
import './Main_2.css';

const MainSection = () => {
  return (
    <div className="section-container">
      <h1 className="section-title">A Modern, Full-Service Pharmacy</h1>
      <p className="section-text">
        At Medicine Center Compounding Pharmacy, we believe health is not just the absence of disease, but a state of immense vitality. It is our mission to help you feel better, live longer, and become the best possible you!
      </p>
    </div>
  );
};

export default MainSection;
