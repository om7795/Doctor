import React from 'react';
import './Main_5.css';

const Main5 = () => {
  const imagePath = './photos/bg3.jpg';
  return (
    <div className="main-container">
      <img
        src={require(`${imagePath}`)}
        alt="Heart Care"
        className="main-image"
      />
      <div className="content-container">
        <h1 className="main-title">Care of Heart</h1>
        <p className="main-description">
          For nearly 25 years, thousands of medical practitioners throughout the
          state of Utah have exclusively referred patients to Medicine Center
          Compounding Pharmacy for their compounded medications. This is due to
          the combination of outstanding service, price, and quality. At
          Medicine Center, quality is paramount. For that reason, we use
          cutting-edge technology, state-of-the-art equipment, innovative bases,
          and some of the most unique dosage forms our industry has to offer.
        </p>
      </div>
    </div>
  );
};

export default Main5;
