import React from 'react';
import './Main_1.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBrain, faHeartbeat, faProcedures } from '@fortawesome/free-solid-svg-icons';

const Main_1 = () => {
  return (
    <div className="main-container">
      <div className="main-card">
        <FontAwesomeIcon icon={faBrain} className="icon-size" />
        <h2 className="main-title">NEUROLOGY CARE</h2>
        <p className="main-description">
          Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.
        </p>
      </div>
      <div className="main-card">
        <FontAwesomeIcon icon={faHeartbeat} className="icon-size" />
        <h2 className="main-title">CARDIOLOGY CARE</h2>
        <p className="main-description">
          Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.
        </p>
      </div>
      <div className="main-card">
        <FontAwesomeIcon icon={faProcedures} className="icon-size" />
        <h2 className="main-title">UROLOGY CARE</h2>
        <p className="main-description">
          Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.
        </p>
      </div>
    </div>
  );
};

export default Main_1;
