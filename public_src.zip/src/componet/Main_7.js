import React from 'react';
import './Main_7.css';

const Main7 = () => {
  const image_Main7_bg4 = './photos/bg4.jpg';
  const image_Main7_bg5 = './photos/bg5.jpeg';
  const image_Main7_bg6 = './photos/bg6.jpg';

  return (
    <div className="Main_7-container">
      <div className="Main_7-content">
        <div className="Main_7-card">
          <img
            src={require(`${image_Main7_bg4}`)}
            alt="Child Care"
            className="Main_7-image"
          />
          <h1 className="Main_7-title">Child Care</h1>
          <p className="Main_7-description">
            Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit
            nullam nunc justo sagittis suscipit ultrices.
          </p>
          <a
            href="#"
            target="_blank"
            rel="noopener noreferrer"
            className="Main_7-link"
          >
            Read More
          </a>
        </div>

        <div className="Main_7-card">
          <img
            src={require(`${image_Main7_bg5}`)}
            alt="Child Care"
            className="Main_7-image"
          />
          <h1 className="Main_7-title">dental care</h1>
          <p className="Main_7-description">
            Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit
            nullam nunc justo sagittis suscipit ultrices.
          </p>
          <a
            href="#"
            target="_blank"
            rel="noopener noreferrer"
            className="Main_7-link"
          >
            Read More
          </a>
        </div>

        <div className="Main_7-card">
          <img
            src={require(`${image_Main7_bg6}`)}
            alt="Child Care"
            className="Main_7-image"
          />
          <h1 className="Main_7-title">birth care</h1>
          <p className="Main_7-description">
            Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit
            nullam nunc justo sagittis suscipit ultrices.
          </p>
          <a
            href="#"
            target="_blank"
            rel="noopener noreferrer"
            className="Main_7-link"
          >
            Read More
          </a>
        </div>
      </div>
    </div>
  );
};

export default Main7;
