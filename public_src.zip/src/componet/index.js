import Header from './Header';
import Main_1 from './Main_1';
import Main_2 from './Main_2';
import Main_3 from './Main_3';
import Main_4 from './Main_4';
import Main_5 from './Main_5';
import Main_6 from './Main_6';
import Main_7 from './Main_7';
import Main_8 from './Main_8';
import Main_9 from './Main_9';

export { Header, Main_1, Main_2, Main_3, Main_4, Main_5, Main_6, Main_7, Main_8, Main_9};



