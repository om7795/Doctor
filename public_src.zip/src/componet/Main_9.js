import React from "react";
import "./footer.css";

function Footer() {
  return (
    <footer className="footer-container">
      <p className="footer-text">
      Website Created by <a href="https://om7795.github.io/Om.com/" target="_blank" rel="noopener noreferrer">OM</a>.
      </p>
    
    </footer>
  );
}

export default Footer;
