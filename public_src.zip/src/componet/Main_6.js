import React from 'react';
import './Main_6.css';

const Main6 = () => {
  return (
    <div className="Main6-container">
      <div className="Main6-content">
        <h1 className="Main6-title">WE CARE</h1>
        <p className="Main6-description">
          Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit nullam nunc justo sagittis suscipit ultrices.
        </p>
      </div>
    </div>
  );
};

export default Main6;
