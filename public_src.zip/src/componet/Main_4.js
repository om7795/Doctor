import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faHeart, faBrain, faTooth, faEarListen, faKitMedical } from '@fortawesome/free-solid-svg-icons';
import './Main_4.css';

const Main4 = () => {
  return (
    <div className="department-section">
      <h1 className="department-title">Our Departments</h1>
      <p className="department-description">
        Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.
      </p>
      <div className="department-card">
        <FontAwesomeIcon icon={faEye} className="department-icon" />
        <h5>Laser Eye Care</h5>
      </div>
      <div className="department-card">
        <FontAwesomeIcon icon={faHeart} className="department-icon" />
        <h5>Heart Care</h5>
      </div>
      <div className="department-card">
        <FontAwesomeIcon icon={faBrain} className="department-icon" />
        <h5>Neurology</h5>
      </div>
      <div className="department-card">
        <FontAwesomeIcon icon={faTooth} className="department-icon" />
        <h5>Dental Care</h5>
      </div>
      <div className="department-card">
        <FontAwesomeIcon icon={faEarListen} className="department-icon" />
        <h5>Ear Care</h5>
      </div>
      <div className="department-card">
        <FontAwesomeIcon icon={faKitMedical} className="department-icon" />
        {/* Emergency icon code */}
        <h5>Emergency</h5>
      </div>
    </div>
  );
};

export default Main4;
