import React from "react";
import './Main_8.css';

function Main8() {
  return (
    <div className="contact-container">
      <h1 className="contact-title">GET IN TOUCH</h1>
      <p className="contact-subtitle">
        Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit
        nullam nunc justo sagittis suscipit ultrices.
      </p>
      <form className="contact-form">
        <input
          type="text"
          className="form-input"
          placeholder="Enter your Name"
        />
        <input
          type="email"
          className="form-input"
          placeholder="Enter a valid email address"
        />
        <textarea
          className="form-textarea"
          placeholder="Enter your message"
        ></textarea>
        <button type="submit" className="form-button">
          SUBMIT
        </button>
      </form>
    </div>
  );
}

export default Main8;
