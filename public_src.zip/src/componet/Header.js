import React from 'react';
import './header.css';

const Header = () => {
  return (
    <header className="header-section">
      <div className="header-wrapper">
        <h1 className="header-title">Medicine Center On The Go!</h1>
        <p className="header-description">
          With the new Medicine Center app, the high-quality service that we are known for is now available via your smartphone. Available on the{' '}
          <a href="#" className="header-link">App Store</a> and <a href="#" className="header-link">Google Play</a>.
        </p>
        <button className="header-cta-button">Read More</button>
      </div>
    </header>
  );
};

export default Header;
