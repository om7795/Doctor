import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBrain, faHeartbeat, faAmbulance } from '@fortawesome/free-solid-svg-icons'; // Importing faAmbulance
import './Main_3.css';

const Main3 = () => {
  return (
    <div className="section-background">
      <div className="card-container">
        <div className="card">
          <div className="card-icon">
            <FontAwesomeIcon icon={faBrain} className="icon-style" />
          </div>
          <div className="card-content">
            <h3>NEUROLOGICAL</h3>
            <p>Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.</p>
          </div>
        </div>
        <div className="card">
          <div className="card-icon">
            <FontAwesomeIcon icon={faHeartbeat} className="icon-style" />
          </div>
          <div className="card-content">
            <h3>CARDIOLOGICAL</h3>
            <p>Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.</p>
          </div>
        </div>
        <div className="card">
          <div className="card-icon">
            <FontAwesomeIcon icon={faAmbulance} className="icon-style" /> {/* Updated icon to faAmbulance */}
          </div>
          <div className="card-content">
            <h3>24 hrs emergency</h3>
            <p>Sample text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nunc justo sagittis suscipit ultrices.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main3;
